#include<stdio.h>
#include<string.h>
#include"../Include/NetDDS.h"
int main()
{
	DDS *one = new NetDDS();
	Publisher *p;
	char topic[128] = "";
	char mes[1024] = "";
	printf("��������:");
	scanf("%s", topic);
	p = one->CreateQueuingPublisher(topic, sizeof(topic));
	while (1)
	{
		printf("[%s]<<��",topic);
		scanf("%s", mes);

		p->DataWriter(mes, sizeof(mes), INFINITE);
	}

	return 0;
}