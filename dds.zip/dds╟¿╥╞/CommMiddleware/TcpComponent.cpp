#include "tcpcomponent.h"
#include <stdio.h>

TcpComponent::TcpComponent(char *lpszServerIPAddress,unsigned short uServerPort,char *lpszLocalIPAddress,unsigned short uLocalPort)
{
	struct	sockaddr_in addr;
	struct	linger Linger;
	char	*lpszIPAddress;
	int		opt;

	INIT_LIST_HEAD(&m_ConnectedItem);

	if((m_nSocket = socket(AF_INET,SOCK_STREAM,0)) >= 0)
	{
		Linger.l_onoff = 1;
		Linger.l_linger = 3;
		//����socket��close()�ķ�ʽ ->��ʱ֮�������ر�
		setsockopt(m_nSocket,SOL_SOCKET,SO_LINGER,(char *)&Linger,sizeof(Linger));	
		if (lpszLocalIPAddress || uLocalPort)
		{
			if (lpszLocalIPAddress)
			{
				lpszIPAddress = lpszLocalIPAddress;
			}
			else
			{
				lpszIPAddress = (char *)"0.0.0.0";
			}
			memset(&addr, 0, sizeof(struct sockaddr_in));
			addr.sin_family = AF_INET;
			addr.sin_port = htons(uLocalPort);
			addr.sin_addr.S_un.S_addr = inet_addr(lpszIPAddress);

			if (bind(m_nSocket,(struct sockaddr *)&addr,sizeof(addr)) < 0)
			{
				closesocket(m_nSocket);
				m_nSocket = INVALID_SOCKET;
				return;
			}
		}
		if (lpszServerIPAddress)
		{
			lpszIPAddress = lpszServerIPAddress;
		}
		else
		{
			lpszIPAddress = (char *)"0.0.0.0";
		}

		m_uRemoteIPAddress  = ntohl(inet_addr(lpszIPAddress));
		m_uRemotePort		= uServerPort;

		memset(&addr, 0, sizeof(struct sockaddr_in));
		addr.sin_family = AF_INET;
		addr.sin_port = htons(uServerPort);

		addr.sin_addr.S_un.S_addr = inet_addr(lpszIPAddress);


		opt = 1;
		setsockopt(m_nSocket, IPPROTO_TCP, TCP_NODELAY, (char *)&opt, sizeof(opt));

		//���������������
		if (connect(m_nSocket,(struct sockaddr *)&addr,sizeof(addr)) != 0) 
		{
			closesocket(m_nSocket);
			m_nSocket = INVALID_SOCKET;
		}

		opt = 1;
		setsockopt(m_nSocket, IPPROTO_TCP, TCP_NODELAY, (char *)&opt, sizeof(opt));
	}
}

TcpComponent::~TcpComponent()
{
	ListDel(&m_ConnectedItem);
	if (m_nSocket != INVALID_SOCKET)
	{
		closesocket(m_nSocket);
		m_nSocket = INVALID_SOCKET;
	}
}

int TcpComponent::IsValid()
{
	if (m_nSocket == INVALID_SOCKET)
	{
		return 0;
	}
	else
	{
		return 1;
	}
}

void TcpComponent::GetAddress(unsigned int *uRemoteIPAddress,unsigned short *uRemotePort,unsigned int *uLocalIPAddress,unsigned short *uLocalPort)
{
	struct sockaddr_in name;

	int namelen;

	if (uRemoteIPAddress)
	{
		*uRemoteIPAddress = m_uRemoteIPAddress;
	}
	if (uRemotePort)
	{
		*uRemotePort = m_uRemotePort;
	}
	namelen = sizeof(struct sockaddr);
	if (!getsockname(m_nSocket,(struct sockaddr *)&name,&namelen))
	{
		if (uLocalIPAddress)
		{

			*uLocalIPAddress = ntohl(name.sin_addr.S_un.S_addr);

		}
		if (uLocalPort)
		{
			*uLocalPort = ntohs(name.sin_port);
		}
	}
}

void TcpComponent::GetAddress(char *lpszRemoteIPAddress,unsigned short *uRemotePort,char *lpszLocalIPAddress,unsigned short *uLocalPort)
{
	unsigned int uRemoteIPAddress,uLocalIPAddress;

	GetAddress(&uRemoteIPAddress,uRemotePort,&uLocalIPAddress,uLocalPort);

	if (lpszRemoteIPAddress)
	{
		IPtoA(uRemoteIPAddress,lpszRemoteIPAddress);
	}
	if (lpszLocalIPAddress)
	{
		IPtoA(uLocalIPAddress,lpszLocalIPAddress);
	}
}

int TcpComponent::Send(char *lpszMessage,int nMsgLen0,char *lpszMessage1,int nMsgLen1,int bMulti)
{
	WSABUF WsaBuffer[3];
	DWORD dwBufferCount = 2;
	DWORD dwNumberOfBytesSent;
	int nLen = nMsgLen0 + nMsgLen1;

	WsaBuffer[0].len = sizeof(int);
	WsaBuffer[0].buf = (char *)&nLen;

	WsaBuffer[1].len = nMsgLen0;
	WsaBuffer[1].buf = lpszMessage;
	if (nMsgLen1 > 0)
	{
		dwBufferCount++;
		WsaBuffer[2].len = nMsgLen1;
		WsaBuffer[2].buf = lpszMessage1;
	}
	if (!WSASend(m_nSocket,WsaBuffer,dwBufferCount,&dwNumberOfBytesSent,MSG_DONTROUTE,NULL,NULL))	//һ�η��Ͷ������bufferS
	{
		
		return dwNumberOfBytesSent;			// ���ͳɹ� ָ�������������ֽ�����ָ��
	}
	else
	{
		return -1;
	}
}

int TcpComponent::Send(unsigned int uRemoteIPAddress,unsigned short uRemotePort,char *lpszMessage,int nMsgLen,char *lpszMessage1,int nLen1)
{
	if (m_uRemoteIPAddress == uRemoteIPAddress && m_uRemotePort == uRemotePort)
	{
		return Send(lpszMessage,nMsgLen);
	}
	else
	{
		return 0;
	}
}

int TcpComponent::Send(char *lpRemoteszIPAddress,unsigned short uRemotePort,char *lpszMessage,int nMsgLen,char *lpszMessage1,int nLen1)
{
	return Send(lpszMessage,nMsgLen);
}

int TcpComponent::Recv(char *lpszMessage,int nMsgLen,int bBlocked,int nTimeout)
{
	int i,k,n,m;
	char *p;
	int len;
	fd_set readfd;
	struct timeval timeout;
	BOOL bRead;
	int nStatus=0;

	if (bBlocked)
	{
		FD_ZERO(&readfd);
		FD_SET(m_nSocket,&readfd);
		timeout.tv_sec = 0;
		timeout.tv_usec = 0;

		nStatus = select(0,&readfd,NULL,NULL,&timeout);

		bRead = FD_ISSET(m_nSocket,&readfd);
	}
	else
	{
		bRead = TRUE;
	}
	if (bRead)
	{
		p = (char *)&len;
		m = sizeof(int);
		n = 0;
		k = 0;
		for (i=0;i<2;i++)
		{
			do {
				m -= k;
				n += k;
				if (n != 0) Sleep(0);
				k = recv(m_nSocket,&p[n],m,0);
			}	while ((k > 0) && (k<m));
			if (k < m) 
			{
				return -1;
			}
			m = len;
			p = lpszMessage;
			if (m > nMsgLen)
			{
				return -1;
			}
			n = 0;
			k = 0;
		}

		return len;
	}
	return 0;
}

int TcpComponent::Recv(unsigned int *uRemoteIPAddress,unsigned short *uRemotePort,char *lpszMessage,int nMsgLen)
{
	if (uRemoteIPAddress)
	{
		*uRemoteIPAddress = m_uRemoteIPAddress;
	}
	if (uRemotePort)
	{
		*uRemotePort = m_uRemotePort;
	}
	return Recv(lpszMessage,nMsgLen);
}

int TcpComponent::Recv(char *lpszRemoteIPAddress,unsigned short *uRemotePort,char *lpszMessage,int nMsgLen)
{
	if (lpszRemoteIPAddress)
	{
		IPtoA(m_uRemoteIPAddress,lpszRemoteIPAddress);
	}
	if (uRemotePort)
	{
		*uRemotePort = m_uRemotePort;
	}
	return Recv(lpszMessage,nMsgLen);
}
