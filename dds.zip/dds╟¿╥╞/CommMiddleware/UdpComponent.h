#ifndef __UDP_COMPONENT_H__
#define __UDP_COMPONENT_H__

#include "../include/commmiddleware.h"

class UdpComponent : public CommComponent
{
	private:
		unsigned int		m_uRemoteIPAddress; 
		unsigned short		m_uRemotePort;
	
	private:
		virtual ~UdpComponent();
	
	public:
		UdpComponent(char *lpszServerIPAddress,unsigned short uServerPort,char *lpszLocalIPAddress=0,unsigned short uLocalPort=0);

		int IsValid();

		void GetAddress(unsigned int *uRemoteIPAddress,unsigned short *uRemotePort,unsigned int *uLocalIPAddress=0,unsigned short *uLocalPort=0);
		void GetAddress(char *lpszRemoteIPAddress,unsigned short *uRemotePort,char *lpszLocalIPAddress=0,unsigned short *uLocalPort=0);

		int Send(char *lpszMessage,int nLen,char *lpszMessage1=0,int nLen1=0,int bMulti=0);
		int Send(unsigned int uRemoteIPAddress,unsigned short uRemotePort,char *lpszMessage,int nLen,char *lpszMessage1=0,int nLen1=0);
		int Send(char *lpszRemoteIPAddress,unsigned short uRemotePort,char *lpszMessage,int nLen,char *lpszMessage1=0,int nLen1=0);

		int Recv(char *lpszMessage,int nLen,int bBlocked = 0,int nTimeout = 0);
		int Recv(unsigned int *uRemoteIPAddress,unsigned short *uRemotePort,char *lpszMessage,int nLen);
		int Recv(char *lpszRemoteIPAddress,unsigned short *uRemotePort,char *lpszMessage,int nLen);

};

#endif /* __UDP_COMPONENT_H__ */
