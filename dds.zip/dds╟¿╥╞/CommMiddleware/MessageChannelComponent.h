#ifndef __MESSAGE_CHANNEL_COMPONENT_H__
#define __MESSAGE_CHANNEL_COMPONENT_H__

#include "tcpservercomponent.h"
//���ܣ�����������Ϣ
class MessageChannelComponent : public TcpServerComponent
{
	private:
		char			m_szMessage[MAX_MESSAGE_LEN];  //��Ϣ
		volatile int	m_bBrigeStoped;                //�ж��Ƿ�ֹͣ

	private:

		static DWORD Brige(void *arg);

		CommComponent *GetTcpComponent(char *lpszRemoteIPAddress,unsigned short *uRemotePort){ return 0; };
		CommComponent *GetTcpComponent(unsigned int uRemoteIPAddress,unsigned short uRemotePort = 0){ return 0; };
		CommComponent *GetTcpComponent(char *lpszRemoteIPAddress,unsigned short uRemotePort = 0){ return 0; };

	public:
		MessageChannelComponent(char *lpszServerIPAddress,unsigned short uServerPort);
		~MessageChannelComponent();
};

#endif /* __MESSAGE_CHANNEL_COMPONENT_H__*/
