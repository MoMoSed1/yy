#include "tcpservercomponent.h"
#include <stdio.h>
#include <time.h>

TcpServerComponent::TcpServerComponent(char *lpszServerIPAddress,unsigned short uServerPort)
	:
	m_lpNotifyComponent(0),
	m_lpAnnouncedComponent(0),
	m_hConnectEvent(0),
	m_nConnectEventNo(0)
{
	struct sockaddr_in addr;
	char *lpszIPAddress;
	struct sockaddr_in name;
	int opt;
	int namelen;

	INIT_LIST_HEAD(&m_ConnectedList);              //��ʼ����������
	InitializeCriticalSection(&m_CriticalSection); //��ʼ���ؼ���

	if((m_nSocket = socket(AF_INET,SOCK_STREAM,0)) >= 0)  //��������׽��ֳɹ�
	{
		opt = 1;
		setsockopt(m_nSocket, SOL_SOCKET, SO_REUSEADDR, (char *)&opt, sizeof(opt));
		if (lpszServerIPAddress)
		{
			lpszIPAddress = lpszServerIPAddress;
		}
		else
		{
			lpszIPAddress = (char *)"0.0.0.0";
		}
		memset(&addr, 0, sizeof(struct sockaddr_in));

		addr.sin_family = AF_INET;
		addr.sin_port = htons(uServerPort);
		addr.sin_addr.S_un.S_addr = inet_addr(lpszIPAddress);

		if (bind(m_nSocket,(struct sockaddr *)&addr,sizeof(addr)) < 0) //���׽��ֺͱ���IP�����ض˿ڽ��а�
		{
			closesocket(m_nSocket);
			m_nSocket = INVALID_SOCKET;
		}
		else //�󶨳ɹ�
		{
			m_bRunning = 0;
			m_bAcceptStoped	= 0;

			listen(m_nSocket,5);   //���׽�������Ϊ����ģʽ

			//�����̣߳������ͻ�����������
			CreateThread(0, 0 ,(LPTHREAD_START_ROUTINE)TcpAccept,this,0,0);

			while (!m_bRunning)
			{
				Sleep(0);   //���������û�п�ʼ���У���ǰ�߳�һֱ�ó�CPU����Ȩ
			}
			namelen = sizeof(struct sockaddr);
			if (!getsockname(m_nSocket,(struct sockaddr *)&name,&namelen))
			{
				m_lpNotifyComponent = CommFactroy(TCP_COMPONENT,lpszServerIPAddress,ntohs(name.sin_port));
			}
		}
	}
}

TcpServerComponent::~TcpServerComponent()
{
	if (m_hConnectEvent)
	{
		CloseHandle(m_hConnectEvent);
	}
	ReleaseTcpComponent();
	while (!m_bAcceptStoped)
	{
		Sleep(1);
	}
}

void TcpServerComponent::ReleaseTcpComponent()
{
	m_bRunning = 0;
	TcpComponent *lpTcpComponent,*lpNextTcpComponent;

	EnterCriticalSection(&m_CriticalSection);

	if (m_lpNotifyComponent)
	{
		delete m_lpNotifyComponent;
		m_lpNotifyComponent = 0;
	}
	if (m_lpAnnouncedComponent)
	{
		delete m_lpAnnouncedComponent;
		m_lpAnnouncedComponent = 0;
	}
	ListForEachEntrySafe(TcpComponent,lpTcpComponent,lpNextTcpComponent, &m_ConnectedList, m_ConnectedItem)
	{
		delete lpTcpComponent;
	}

	LeaveCriticalSection(&m_CriticalSection);

	if (m_nSocket != INVALID_SOCKET)
	{
		closesocket(m_nSocket);
		m_nSocket = INVALID_SOCKET;
	}
}

//checkConnect���ã�
void TcpServerComponent::CheckConnect()
{
	if (m_hConnectEvent)
	{
		if (ListIsEmpty(&m_ConnectedList))   //1��ʾ����Ϊ��
		{
			if (WaitForSingleObject(m_hConnectEvent,MAX_SUBSCRIBE_TIME_DELAY) == WAIT_TIMEOUT)
			{
				EnterCriticalSection(&m_CriticalSection);
				if (m_hConnectEvent)
				{
					CloseHandle(m_hConnectEvent);
					m_hConnectEvent = 0;
				}
				LeaveCriticalSection(&m_CriticalSection);
			}
		}
	}
}


DWORD TcpServerComponent::TcpAccept(void *arg)
{
	int opt;
	SOCKET nNewSocket;
	struct sockaddr_in addr;
	TcpServerComponent *lpTcpServerComponent;
	TcpComponent *lpTcpComponent = 0;
	unsigned int uLocalAddress;
	unsigned short uLocalPort;
	CommComponent *lpCommComponent;

	int addrlen;

	lpTcpServerComponent = (TcpServerComponent *)arg;

	SetThreadPriority(GetCurrentThread(),THREAD_PRIORITY_TIME_CRITICAL);  //���߳����ȼ��������

	opt = 1;
	setsockopt(lpTcpServerComponent->m_nSocket, IPPROTO_TCP, TCP_NODELAY, (char *)&opt, sizeof(opt));


	lpTcpServerComponent->m_bRunning = 1;
	do
	{
		addrlen = sizeof(addr);
		nNewSocket = accept(lpTcpServerComponent->m_nSocket,(struct sockaddr *)&addr,&addrlen);

		EnterCriticalSection(&lpTcpServerComponent->m_CriticalSection);

		if (nNewSocket != INVALID_SOCKET)
		{

			opt = 1;
			setsockopt(nNewSocket, IPPROTO_TCP, TCP_NODELAY, (char *)&opt, sizeof(opt));

			lpTcpComponent						= new TcpComponent;
			lpTcpComponent->m_nSocket			= nNewSocket;

			lpTcpComponent->m_uRemoteIPAddress	= ntohl(addr.sin_addr.S_un.S_addr);

			lpTcpComponent->m_uRemotePort		= ntohs(addr.sin_port);

			INIT_LIST_HEAD(&lpTcpComponent->m_ConnectedItem);

			if (!lpTcpServerComponent->m_lpAnnouncedComponent && lpTcpServerComponent->m_lpNotifyComponent)
			{ //�����֪ͨ�����û�й������������һ�����صĹ������
				lpCommComponent = (CommComponent *)lpTcpServerComponent->m_lpNotifyComponent;
				lpCommComponent->GetAddress(0,0,&uLocalAddress,&uLocalPort);  //��ȡ��֪ͨ�������ı���IP�Ͷ˿ں�

				//���lpTcpComponent��Զ�˵�ַ�Ͷ˿ڶ��Ǳ���ip�Ͷ˿�,�������������һ�����صĹ������
				//�����������������һ���ͻ��ˣ��������ӵ�����������
				if (lpTcpComponent->m_uRemoteIPAddress == uLocalAddress && lpTcpComponent->m_uRemotePort == uLocalPort)
				{ 
					lpTcpServerComponent->m_lpAnnouncedComponent = lpTcpComponent;
				}
				else
				{
					//���ͻ��˵���������ص�����������
					ListAddTail(&lpTcpComponent->m_ConnectedItem,&lpTcpServerComponent->m_ConnectedList);
				}
			}
			else
			{
			    //���û�н������ص�֪ͨ����������Ѿ���������֪ͨ����͹���������򽫿ͻ��˵���������ص�����������
				ListAddTail(&lpTcpComponent->m_ConnectedItem,&lpTcpServerComponent->m_ConnectedList);
				
				if (lpTcpServerComponent->m_hConnectEvent)
				{
					SetEvent(lpTcpServerComponent->m_hConnectEvent); 
					CloseHandle(lpTcpServerComponent->m_hConnectEvent);
					Sleep(1);
					lpTcpServerComponent->m_hConnectEvent = 0;
				}

			}

			lpCommComponent = (CommComponent *)lpTcpServerComponent->m_lpNotifyComponent;
			if (lpCommComponent)
			{
				lpCommComponent->Send((char *)"NewConnect",11);
			}
		}

		LeaveCriticalSection(&lpTcpServerComponent->m_CriticalSection);

	} while (lpTcpServerComponent->m_bRunning);

	lpTcpServerComponent->m_bAcceptStoped = 1;
	return 0;
}
//�ж��Ƿ񴴽����׽���
int TcpServerComponent::IsValid()
{
	if (m_nSocket == INVALID_SOCKET)
	{
		return 0;
	}
	else
	{
		return 1;
	}
}
//���������¼�
void TcpServerComponent::SetConnectEvent()
{
	char szEventName[128];

	EnterCriticalSection(&m_CriticalSection);
	
	if (!m_hConnectEvent)
	{
		sprintf(szEventName,"__NET_DDS_PUBLISHER_CONNECT_EVENT_%x_%x_%x_%x_%x",GetCurrentProcessId(),GetCurrentThreadId(),time(NULL),GetTickCount(),m_nConnectEventNo++);	
		m_hConnectEvent = CreateEvent(NULL,FALSE,FALSE,szEventName);
	}

	LeaveCriticalSection(&m_CriticalSection);
}

//����IP�Ͷ˿ڷ���һ��TcpComponent
CommComponent *TcpServerComponent::GetTcpComponent(char *lpszRemoteIPAddress,unsigned short *uRemotePort)
{
	TcpComponent *lpTcpComponent,*lpRetComponent = 0;

	EnterCriticalSection(&m_CriticalSection);

	//������������
	ListForEachEntry(TcpComponent,lpTcpComponent, &m_ConnectedList, m_ConnectedItem)
	{
		if (lpszRemoteIPAddress)
		{
			IPtoA(lpTcpComponent->m_uRemoteIPAddress,lpszRemoteIPAddress);
		}
		if (uRemotePort)
		{
			*uRemotePort = lpTcpComponent->m_uRemotePort;
		}
		ListDel(&lpTcpComponent->m_ConnectedItem);
		lpRetComponent = lpTcpComponent;
		break;
	}

	LeaveCriticalSection(&m_CriticalSection);

	return lpRetComponent;
}

CommComponent *TcpServerComponent::GetTcpComponent(unsigned int uRemoteIPAddress,unsigned short uRemotePort)
{
	TcpComponent *lpTcpComponent,*lpRetComponent = 0;

	EnterCriticalSection(&m_CriticalSection);

	ListForEachEntry(TcpComponent,lpTcpComponent, &m_ConnectedList, m_ConnectedItem)
	{
		if (lpTcpComponent->m_uRemoteIPAddress == uRemoteIPAddress && (!uRemotePort || lpTcpComponent->m_uRemotePort == uRemotePort))
		{
			ListDel(&lpTcpComponent->m_ConnectedItem);
			lpRetComponent = lpTcpComponent;
			break;
		}
	}

	LeaveCriticalSection(&m_CriticalSection);
	
	return lpRetComponent;
}

CommComponent *TcpServerComponent::GetTcpComponent(char *lpszRemoteIPAddress,unsigned short uRemotePort)
{
	unsigned int uRemoteIPAddress;

	uRemoteIPAddress = ntohl(inet_addr(lpszRemoteIPAddress)); //��һ�������ֽ�ת��Ϊ�����ֽ�

	return GetTcpComponent(uRemoteIPAddress,uRemotePort);
}

int TcpServerComponent::TcpComponentIsEmpty()
{
	return ListIsEmpty(&m_ConnectedList); //����Ϊ�գ�����1
}

void TcpServerComponent::GetAddress(unsigned int *uServerIPAddress,unsigned short *uServerPort,unsigned int *uLocalIPAddress,unsigned short *uLocalPort)
{
	struct sockaddr_in name;

	int namelen;


	namelen = sizeof(struct sockaddr);
	if (!getsockname(m_nSocket,(struct sockaddr *)&name,&namelen))
	{
		if (uServerIPAddress)
		{
			*uServerIPAddress = ntohl(name.sin_addr.S_un.S_addr);
		}
		if (uServerPort)
		{
			*uServerPort = ntohs(name.sin_port);
		}
	}
}

void TcpServerComponent::GetAddress(char *lpszServerIPAddress,unsigned short *uServerPort,char *lpszLocalIPAddress,unsigned short *uLocalPort)
{
	unsigned int uServerIPAddress;

	GetAddress(&uServerIPAddress,uServerPort);

	if (lpszServerIPAddress)
	{
		IPtoA(uServerIPAddress,lpszServerIPAddress);  //��IP��ַת���ɵ�ֵ��ַ���
	}
}

int TcpServerComponent::Send(char *lpszMessage,int nLen,char *lpszMessage1,int nLen1,int bMulti)
{
	int nNum = 0;
	int nRet;
	TcpComponent *lpTcpComponent,*lpNextTcpComponent;

	CheckConnect();

	EnterCriticalSection(&m_CriticalSection);

	ListForEachEntrySafe(TcpComponent,lpTcpComponent,lpNextTcpComponent,&m_ConnectedList, m_ConnectedItem)
	{
		lpTcpComponent->IsValid();
		nRet = lpTcpComponent->Send(lpszMessage,nLen,lpszMessage1,nLen1,TRUE);
		if (nRet < 0)  //����ʧ�ܣ�lpTcpComponent������ʧ��
		{
			delete lpTcpComponent;
		}
		else
		{
			nNum++;
		}
	}
	LeaveCriticalSection(&m_CriticalSection);
	if (!nNum)
	{
		Sleep(0);
	}
	return nNum;
}

int TcpServerComponent::Send(unsigned int uRemoteIPAddress,unsigned short uRemotePort,char *lpszMessage,int nLen,char *lpszMessage1,int nLen1)
{
	TcpComponent *lpTcpComponent,*lpNextTcpComponent;
	int nRet = 0;;

	CheckConnect();
	EnterCriticalSection(&m_CriticalSection);

	ListForEachEntrySafe(TcpComponent,lpTcpComponent,lpNextTcpComponent,&m_ConnectedList,m_ConnectedItem)
	{
		if (lpTcpComponent->m_uRemoteIPAddress == uRemoteIPAddress && lpTcpComponent->m_uRemotePort == uRemotePort)
		{
			nRet = lpTcpComponent->Send(lpszMessage,nLen,lpszMessage1,nLen1,TRUE);
			if (nRet < 0)
			{
				delete lpTcpComponent;
			}
			else
			{
				break;
			}
		}
	}

	LeaveCriticalSection(&m_CriticalSection);
	return nRet;
}

int TcpServerComponent::Send(char *lpszRemoteIPAddress,unsigned short uRemotePort,char *lpszMessage,int nLen,char *lpszMessage1,int nLen1)
{
	unsigned int uRemoteIPAddress;

	uRemoteIPAddress = ntohl(inet_addr(lpszRemoteIPAddress));

	return Send(uRemoteIPAddress,uRemotePort,lpszMessage,nLen,lpszMessage1,nLen1);
}

int TcpServerComponent::Recv(char *lpszMessage,int nLen,int bBlocked,int nTimeout)
{
	return Recv((unsigned int *)0,0,lpszMessage,nLen);
}

int TcpServerComponent::Recv(unsigned int *uRemoteIPAddress,unsigned short *uRemotePort,char *lpszMessage,int nLen)
{
	int Status;
	fd_set readfd;
	TcpComponent *lpTcpComponent,*lpNextTcpComponent;
	int nRet = 0;;
	char szBufer[128];
	CommComponent *lpCommComponent;

	if (m_lpAnnouncedComponent) //�й������
	{
		FD_ZERO(&readfd); //����������
		
		EnterCriticalSection(&m_CriticalSection);

		FD_SET(m_lpAnnouncedComponent->m_nSocket,&readfd);  //��m_lpAnnouncedComponent->m_nSocket�ļ�����������readfd����


		ListForEachEntry(TcpComponent,lpTcpComponent, &m_ConnectedList, m_ConnectedItem)
		{
			FD_SET(lpTcpComponent->m_nSocket,&readfd); //���������Ӷ�����ļ�����������readfd����
		}
		
		LeaveCriticalSection(&m_CriticalSection);


		//Status == 0 ��ʱ��Status > 0��ȷ��Status == -1����
		Status = select(0,&readfd,NULL,NULL,NULL);  

		lpCommComponent = (CommComponent *)m_lpAnnouncedComponent;

		EnterCriticalSection(&m_CriticalSection);

		if (Status > 0 && FD_ISSET(lpCommComponent->m_nSocket,&readfd)) 
		{
			lpCommComponent->Recv(szBufer,120);
		}
		ListForEachEntrySafe(TcpComponent,lpTcpComponent,lpNextTcpComponent,&m_ConnectedList,m_ConnectedItem)
		{
			if (FD_ISSET(lpTcpComponent->m_nSocket,&readfd))
			{
				if (uRemoteIPAddress)
				{
					*uRemoteIPAddress	= lpTcpComponent->m_uRemoteIPAddress;
				}
				if (uRemotePort)
				{
					*uRemotePort		= lpTcpComponent->m_uRemotePort;
				}
				nRet = lpTcpComponent->Recv(lpszMessage,nLen);
				if (nRet < 0)
				{
					delete lpTcpComponent;  //ɾ������ʧ�ܵ����
				}
				else
				{
					break;
				}
			}
		}

		LeaveCriticalSection(&m_CriticalSection);
	}	
	return nRet;
}

int TcpServerComponent::Recv(char *lpszRemoteIPAddress,unsigned short *uRemotePort,char *lpszMessage,int nLen)
{
	int Status;
	unsigned int uRemoteIPAddress;

	Status = Recv(&uRemoteIPAddress,uRemotePort,lpszMessage,nLen);
	IPtoA(uRemoteIPAddress,lpszRemoteIPAddress);

	return Status;
}
