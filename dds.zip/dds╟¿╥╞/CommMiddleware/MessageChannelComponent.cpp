#include "messagechannelcomponent.h"
#include "tcpcomponent.h"
#include <stdio.h>

MessageChannelComponent::MessageChannelComponent(char *lpszServerIPAddress,unsigned short uServerPort)
	: TcpServerComponent(lpszServerIPAddress,uServerPort),
	  m_bBrigeStoped(0)

{
	CreateThread(0, 0 ,(LPTHREAD_START_ROUTINE)Brige,this,0,0);
}

MessageChannelComponent::~MessageChannelComponent()
{
	ReleaseTcpComponent();
	while (!m_bBrigeStoped)
	{
		Sleep(1);
	}
}

DWORD MessageChannelComponent::Brige(void *arg)
{
	int nLen;
	unsigned short uRemotePort;
	unsigned int uRemoteIPAddress;
	TcpComponent *lpTcpComponent = 0;
	MessageChannelComponent *lpMessageChannelComponent =(MessageChannelComponent *)arg;

	SetThreadPriority(GetCurrentThread(),THREAD_PRIORITY_TIME_CRITICAL);	//�����߳����ȼ� 

	do
	{
		nLen = lpMessageChannelComponent->Recv(&uRemoteIPAddress,&uRemotePort,lpMessageChannelComponent->m_szMessage,MAX_MESSAGE_LEN);

		if (nLen > 0)
		{
			EnterCriticalSection(&lpMessageChannelComponent->m_CriticalSection);
		
			ListForEachEntry(TcpComponent,lpTcpComponent,&(lpMessageChannelComponent->m_ConnectedList),m_ConnectedItem)
			{
				if (lpTcpComponent->m_uRemoteIPAddress != uRemoteIPAddress || lpTcpComponent->m_uRemotePort != uRemotePort)
				{
					lpTcpComponent->Send(lpMessageChannelComponent->m_szMessage,nLen);
				}
			}
			
			LeaveCriticalSection(&lpMessageChannelComponent->m_CriticalSection);
		}
		else
		{
			Sleep(100);
		}
	} while (lpMessageChannelComponent->m_bRunning);

	lpMessageChannelComponent->m_bBrigeStoped = 1;
	return 0;
}
