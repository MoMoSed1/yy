#include "topicchannelcomponent.h"
#include "tcpcomponent.h"
#include <stdio.h>

TopicChannelComponent::TopicChannelComponent(char *lpszServerIPAddress,unsigned short uServerPort,CHANNEL_CALLBACK ChannelCallBack)
	: TcpServerComponent(lpszServerIPAddress,uServerPort),
	  m_ChannelCallBack(ChannelCallBack),
	  m_bBrigeStoped(0)
{
	HANDLE hThread;

	if (m_nSocket != INVALID_SOCKET)
	{

		hThread = CreateThread(0, 0 ,(LPTHREAD_START_ROUTINE)Brige,this,0,0);
		SetThreadPriority(hThread,THREAD_PRIORITY_TIME_CRITICAL);

	}
	else
	{
		m_bBrigeStoped = 1;
	}
}

TopicChannelComponent::~TopicChannelComponent()
{
	ReleaseTcpComponent();
	while (!m_bBrigeStoped)
	{
		Sleep(1);
	}
}

DWORD TopicChannelComponent::Brige(void *arg)

{
	int nLen;
	unsigned short uRemotePort;
	unsigned int uRemoteIPAddress;
	TcpComponent *lpTcpComponent;
	TopicChannelComponent *lpTopicChannelComponent;
	_Topic *lpTopic;

	lpTopicChannelComponent = (TopicChannelComponent *)arg;


	SetThreadPriority(GetCurrentThread(),THREAD_PRIORITY_TIME_CRITICAL);

	lpTopic = &lpTopicChannelComponent->m_Topic;
	do
	{
		nLen = lpTopicChannelComponent->Recv(&uRemoteIPAddress,&uRemotePort,(char *)lpTopic,sizeof(_Topic));

		if (nLen > 0)
		{
			EnterCriticalSection(&lpTopicChannelComponent->m_CriticalSection);
		
			ListForEachEntry(TcpComponent,lpTcpComponent, &lpTopicChannelComponent->m_ConnectedList, m_ConnectedItem)
			{
				if (lpTopic->nType == PUBLISH_TOPIC && lpTopic->uSubscriberIPAddress)
				{
					lpTcpComponent->Send(lpTopic->uSubscriberIPAddress,lpTopic->uSubscriberPort,(char *)lpTopic,sizeof(_Topic));
				}
				else if (lpTopic->nType == SUBSCRIB_TOPIC && lpTopic->uPublisherIPAddress)
				{
					lpTcpComponent->Send(lpTopic->uPublisherIPAddress,lpTopic->uPublisherTopicPort,(char *)lpTopic,sizeof(_Topic));
				}
				else
				{
					lpTcpComponent->Send((char *)lpTopic,sizeof(_Topic));
				}
			}
			
			LeaveCriticalSection(&lpTopicChannelComponent->m_CriticalSection);

			if (lpTopicChannelComponent->m_ChannelCallBack)
			{
				lpTopicChannelComponent->m_ChannelCallBack(lpTopic);
			}

		}
		else
		{
			Sleep(0);
		}
	} while (lpTopicChannelComponent->m_bRunning);

	lpTopicChannelComponent->m_bBrigeStoped = 1;
	return 0;
}
