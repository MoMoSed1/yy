#include "udpcomponent.h"
#include <stdio.h>

UdpComponent::UdpComponent(char *lpszServerIPAddress,unsigned short uServerPort,char *lpszLocalIPAddress,unsigned short uLocalPort)
{
	struct sockaddr_in name;
	struct sockaddr_in addr;
	struct linger Linger;
	struct ip_mreq mreq;
	int opt;
	int namelen;

	if((m_nSocket = socket(AF_INET,SOCK_DGRAM,0)) >= 0)
	{
		Linger.l_onoff = 1;
		Linger.l_linger = 3;
		setsockopt(m_nSocket,SOL_SOCKET,SO_LINGER,(char *)&Linger,sizeof(Linger));

		opt = 1;
		setsockopt(m_nSocket,SOL_SOCKET, SO_REUSEADDR, (char *)&opt, sizeof(opt));

		if (uServerPort)
		{
			//�ͻ����
			memset(&addr, 0, sizeof(struct sockaddr_in));

			addr.sin_family = AF_INET;
			addr.sin_port = htons(uServerPort);

			addr.sin_addr.S_un.S_addr = inet_addr(lpszLocalIPAddress);

			if (bind(m_nSocket,(struct sockaddr *)&addr,sizeof(addr)) < 0)
			{
				closesocket(m_nSocket);
				m_nSocket = INVALID_SOCKET;
				return;
			}

			mreq.imr_multiaddr.s_addr = inet_addr(lpszServerIPAddress);
			mreq.imr_interface.s_addr = inet_addr(lpszLocalIPAddress);
			setsockopt(m_nSocket, IPPROTO_IP, IP_ADD_MEMBERSHIP,(char *) &mreq,sizeof(struct ip_mreq));

			m_uRemoteIPAddress	= ntohl(inet_addr(lpszServerIPAddress));
			m_uRemotePort		= uServerPort;
		}
		else
		{
			//�������
			if (lpszServerIPAddress)
			{
				memset(&addr, 0, sizeof(struct sockaddr_in));
				addr.sin_family = AF_INET;
				addr.sin_port = htons(uLocalPort);

				addr.sin_addr.S_un.S_addr = inet_addr(lpszServerIPAddress);

				if (bind(m_nSocket,(struct sockaddr *)&addr,sizeof(addr)) < 0)
				{
					closesocket(m_nSocket);
					m_nSocket = INVALID_SOCKET;
					return;
				}
				m_uRemoteIPAddress = ntohl(inet_addr(lpszLocalIPAddress));
				namelen = sizeof(struct sockaddr);
				if (!getsockname(m_nSocket,(struct sockaddr *)&name,&namelen))
				{
					m_uRemotePort = ntohs(name.sin_port);
				}
			}
		}
	}
}

UdpComponent::~UdpComponent()
{
	if (m_nSocket != INVALID_SOCKET)
	{
		closesocket(m_nSocket);
		m_nSocket = INVALID_SOCKET;
	}
}

int UdpComponent::IsValid()
{
	if (m_nSocket == INVALID_SOCKET)
	{
		return 0;
	}
	else
	{
		return 1;
	}
}

void UdpComponent::GetAddress(unsigned int *uRemoteIPAddress,unsigned short *uRemotePort,unsigned int *uLocalIPAddress,unsigned short *uLocalPort)
{
	struct sockaddr_in name;

	int namelen;

	if (uRemoteIPAddress)
	{
		*uRemoteIPAddress = m_uRemoteIPAddress;
	}
	if (uRemotePort)
	{
		*uRemotePort = m_uRemotePort;
	}
	namelen = sizeof(struct sockaddr);
	if (!getsockname(m_nSocket,(struct sockaddr *)&name,&namelen))
	{
		if (uLocalIPAddress)
		{

			*uLocalIPAddress = ntohl(name.sin_addr.S_un.S_addr);

		}
		if (uLocalPort)
		{
			*uLocalPort = ntohs(name.sin_port);
		}
	}
}

void UdpComponent::GetAddress(char *lpszRemoteIPAddress,unsigned short *uRemotePort,char *lpszLocalIPAddress,unsigned short *uLocalPort)
{
	unsigned int uRemoteIPAddress,uLocalIPAddress;

	GetAddress(&uRemoteIPAddress,uRemotePort,&uLocalIPAddress,uLocalPort);

	if (lpszRemoteIPAddress)
	{
		IPtoA(uRemoteIPAddress,lpszRemoteIPAddress);
	}
	if (lpszLocalIPAddress)
	{
		IPtoA(uLocalIPAddress,lpszLocalIPAddress);
	}
}

int UdpComponent::Send(char *lpszMessage,int nLen,char *lpszMessage1,int nLen1,int bMulti)
{

	WSABUF WsaBuffer[2];
	DWORD dwNumberOfBytesSent;
	DWORD dwBufferCount = 1;

	struct sockaddr_in addr;

	memset(&addr, 0, sizeof(struct sockaddr_in));
	addr.sin_family = AF_INET;
	addr.sin_port = htons(m_uRemotePort);

	addr.sin_addr.S_un.S_addr = htonl(m_uRemoteIPAddress);



	WsaBuffer[0].len = nLen;
	WsaBuffer[0].buf = lpszMessage;
	if (nLen1 > 0)
	{
		dwBufferCount++;
		WsaBuffer[1].len = nLen1;
		WsaBuffer[1].buf = lpszMessage1;
	}
	if (!WSASendTo(m_nSocket,WsaBuffer,dwBufferCount,&dwNumberOfBytesSent,MSG_DONTROUTE,
									(struct sockaddr *)&addr,sizeof(struct sockaddr_in),NULL,NULL))
	{
		return dwNumberOfBytesSent;
	}
	else
	{
		return -1;
	}
}

int UdpComponent::Recv(char *lpszMessage,int nLen,int bBlocked,int nTimeout)
{
	struct sockaddr src_address;

	int address_len = sizeof(src_address);
	
	return recvfrom(m_nSocket,lpszMessage,nLen,0,&src_address,&address_len);
}

int UdpComponent::Send(unsigned int uIPAddress,unsigned short uPort,char *lpszMessage,int nLen,char *lpszMessage1,int nLen1)
{
	struct sockaddr_in addr;

	memset(&addr, 0, sizeof(struct sockaddr_in));
	addr.sin_family = AF_INET;
	addr.sin_port = htons(uPort);

	addr.sin_addr.S_un.S_addr = htonl(uIPAddress);


	return sendto(m_nSocket,lpszMessage,nLen,MSG_NOSIGNAL,(struct sockaddr *)&addr,sizeof(struct sockaddr_in));
}

int UdpComponent::Recv(unsigned int *uIPAddress,unsigned short *uPort,char *lpszMessage,int nLen)
{
	struct sockaddr_in *addr;
	struct sockaddr src_address;
	int ret;

	int address_len = sizeof(src_address);


	addr = (struct sockaddr_in *)&src_address;
	ret = recvfrom(m_nSocket,lpszMessage,nLen,0,&src_address,&address_len);

	if (uIPAddress)
	{

		*uIPAddress = ntohl(addr->sin_addr.S_un.S_addr);

	}
	if (uPort)
	{
		*uPort = ntohs(addr->sin_port);
	}
	return ret;
}

int UdpComponent::Send(char *lpszIPAddress,unsigned short uPort,char *lpszMessage,int nLen,char *lpszMessage1,int nLen1)
{
	struct sockaddr_in addr;

	memset(&addr, 0, sizeof(struct sockaddr_in));
	addr.sin_family = AF_INET;
	addr.sin_port = htons(uPort);

	addr.sin_addr.S_un.S_addr = inet_addr(lpszIPAddress);

	return sendto(m_nSocket,lpszMessage,nLen,MSG_NOSIGNAL,(struct sockaddr *)&addr,sizeof(struct sockaddr_in));
}

int UdpComponent::Recv(char *lpszIPAddress,unsigned short *uPort,char *lpszMessage,int nLen)
{
	struct sockaddr_in *addr;
	struct sockaddr src_address;
	unsigned long uIPAddress;

	int address_len = sizeof(src_address);

	int ret;

	addr = (struct sockaddr_in *)&src_address;
	ret = recvfrom(m_nSocket,lpszMessage,nLen,0,&src_address,&address_len);
	if (lpszIPAddress)
	{

		uIPAddress = ntohl(addr->sin_addr.S_un.S_addr);

		IPtoA(uIPAddress,lpszIPAddress);
	}
	if (uPort)
	{
		*uPort = ntohs(addr->sin_port);
	}
	return ret;
}
