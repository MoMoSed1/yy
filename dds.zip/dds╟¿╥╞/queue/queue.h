#pragma once
#include<stdio.h>
#ifndef __QUEUE_H__
#define __QUEUE_H__

/////////////////////////////////////////////////////////////////////////////////////////////////
//
//											��    ��
//
/////////////////////////////////////////////////////////////////////////////////////////////////
#ifndef LIST_HEAD_DEF

#define LIST_HEAD_DEF
typedef struct LIST_HEAD
{
	volatile struct LIST_HEAD *Next;
	volatile struct LIST_HEAD *Prev;
} LIST_HEAD;

#endif /*LIST_HEAD_DEF*/

#define INIT_LIST_HEAD(ptr) do { \
		(ptr)->Next = ptr; (ptr)->Prev = ptr; \
	} while (0)

#define EMPTY_LIST_HEAD(ptr) do { \
		(ptr)->Next = 0; (ptr)->Prev = 0; \
	} while (0)



#define offset_of(TYPE, MEMBER) ((size_t) &((TYPE *)0)->MEMBER)		//���ΪʲôҪ�� & 
#define container_of(ptr, type, member) (type *)((char *)ptr - offset_of(type, member))


#define list_entry(ptr, type, member)   container_of(ptr, type, member)	//����ptr�ṹ����׵�ַ 

#define ListForEachEntry(type,pos, head, member)				\
	for (pos = list_entry((head)->Next, type, member);			\
	     pos->member.Next, &pos->member != (head); 				\
	     pos = list_entry(pos->member.Next, type, member))

#define ListForEachEntrySafe(type,pos, n, head, member)			\
	for (pos = list_entry((head)->Next, type, member),			\
		 n = list_entry(pos->member.Next, type, member);		\
	     &pos->member != (head); 								\
	     pos = n, n = list_entry(n->member.Next, type, member))


void ListAddHead(LIST_HEAD *New, LIST_HEAD *Head);
void ListInsert(LIST_HEAD *New, LIST_HEAD *Pos);
void ListAddTail(LIST_HEAD *New, LIST_HEAD *Head);
void ListDel(LIST_HEAD *entry);
int  ListIsEmpty(const LIST_HEAD *Head);
#endif /* __QUEUE_H__ */