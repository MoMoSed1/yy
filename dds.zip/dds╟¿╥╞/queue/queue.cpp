#include "queue.h"

/////////////////////////////////////////////////////////////////////////////////////////////////
//
//												��    ��
//
/////////////////////////////////////////////////////////////////////////////////////////////////
static void ListAdd(LIST_HEAD *New, LIST_HEAD *Prev, LIST_HEAD *Next)
{
	Next->Prev = New;
	New->Next = Next;
	New->Prev = Prev;
	Prev->Next = New;
}

void ListAddHead(LIST_HEAD *New, LIST_HEAD *Head)
{
	ListAdd(New, (LIST_HEAD *)Head->Next, Head);
}

void ListAddTail(LIST_HEAD *New, LIST_HEAD *Head)
{
	ListAdd(New, (LIST_HEAD *)Head->Prev, Head);
}

void ListInsert(LIST_HEAD *New, LIST_HEAD *Pos)
{
	Pos->Prev->Next = New;
	New->Next = Pos;
	New->Prev = Pos->Prev;
	Pos->Prev = New;
}

static void __ListDel(LIST_HEAD * Prev, LIST_HEAD * Next)
{
	Next->Prev = Prev;
	Prev->Next = Next;
}

void ListDel(LIST_HEAD *entry)
{
	if (entry->Prev)
	{
		__ListDel((LIST_HEAD *)entry->Prev, (LIST_HEAD *)entry->Next);
		entry->Prev = 0;
		entry->Next = 0;
	}
}

int ListIsEmpty(const LIST_HEAD *Head)
{
	return (LIST_HEAD *)Head->Next == Head;
}

