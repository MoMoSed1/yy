#include<stdio.h>
//#include<Windows.h>
#include"../Include/NetDDS.h"

int main()
{
	DDS *one = new NetDDS();
	Subscriber	*s;
	char topic[128] = "";
	char mes[1024] = "";
	printf("�������⣺");
	scanf("%s", topic);
	s = one->CreateQueuingSubscriber(topic, sizeof(topic));
	while (1)
	{
		int len=s->DataReader(mes, sizeof(mes), INFINITE);
		if (len > 0)
			printf("[%s]>>%s\n",topic, mes);
		else
			Sleep(1000);
	}

	return 0;
}