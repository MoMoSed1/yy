#include "../include/netdds.h"
#include "../include/commmiddleware.h"
#include "../queue/queue/queue.h"
#include <stdio.h>


CommComponent *s_lpEventSocket = 0;
CRITICAL_SECTION s_ThreadCriticalSection;

Receiver::Receiver(NetDDSSubscriber *lpSubscriber,_Topic *lpTopic)
{
	char szIPAddress[32];
	char szSubscriberIPAddress[32];
	m_uPublisherIPAddress = lpTopic->uPublisherIPAddress;
	m_uPublisherPort = lpTopic->uPublisherPort;
	IPtoA(lpTopic->uPublisherIPAddress,szIPAddress);

	if (lpTopic->nClass == TOPIC_QUEUE)
	{
		m_lpSubscriberChannel = CommFactroy(TCP_COMPONENT,szIPAddress,lpTopic->uPublisherPort);
	}
	else
	{
		IPtoA(lpTopic->uSubscriberIPAddress,szSubscriberIPAddress);
		m_lpSubscriberChannel = CommFactroy(UDP_COMPONENT,szIPAddress,lpTopic->uPublisherPort,szSubscriberIPAddress);
	}
}

Receiver::~Receiver()
{
	ListDel(&m_ReceiverItem);

	if (m_lpSubscriberChannel)
	{
		CommDestroy(m_lpSubscriberChannel);
		m_lpSubscriberChannel = 0;
	}
}

NetDDSSubscriber::NetDDSSubscriber(CommComponent *lpTopicChannel,unsigned int uLocalIPAddress,unsigned short uLocalPort,
																						char *lpszTopic,int nSize,int nClass)
{
	m_lpTopicChannel = lpTopicChannel;
	m_nClass		 = nClass;
	m_bEmpty		 = TRUE;
	m_nSize			 = nSize;
	m_lpMessage		 = malloc(nSize);

	EMPTY_LIST_HEAD(&m_SubscriberItem);
	INIT_LIST_HEAD(&m_ReceiverList);

	InitializeCriticalSection(&m_CriticalSection);

	if (!s_lpEventSocket)
	{
		s_lpEventSocket = CommFactroy(UDP_COMPONENT,(char *)"127.0.0.1",0,(char *)"127.0.0.1");
		InitializeCriticalSection(&s_ThreadCriticalSection);
	}

	strcpy(m_Topic.szTopic,lpszTopic);
	m_Topic.nDDS					= NET_DDS;
	m_Topic.nType					= SUBSCRIB_TOPIC;
	m_Topic.nSize					= nSize;
	m_Topic.nClass					= nClass;
	m_Topic.uPublisherIPAddress		= 0;
	m_Topic.uPublisherPort			= 0;
	m_Topic.uPublisherTopicPort		= 0;
	m_Topic.uSubscriberIPAddress	= uLocalIPAddress;
	m_Topic.uSubscriberPort			= uLocalPort;
	
	if (uLocalIPAddress)
	{
		m_lpTopicChannel->Send((char *)&m_Topic,sizeof(m_Topic));
	}
}

NetDDSSubscriber::~NetDDSSubscriber()
{
	Receiver *lpReceiver,*lpNextReceiver;

	free(m_lpMessage);

	ListDel(&m_SubscriberItem);

	EnterCriticalSection(&m_CriticalSection);
	
	ListForEachEntrySafe(Receiver,lpReceiver,lpNextReceiver,&m_ReceiverList,m_ReceiverItem)
	{
		delete lpReceiver;
	}

	delete s_lpEventSocket;

	LeaveCriticalSection(&m_CriticalSection);
}

void NetDDSSubscriber::ConnectPublisher(_Topic *lpTopic)
{
	int bFound = 0;
	Receiver *lpReceiver;
	if (!strcmp(lpTopic->szTopic,m_Topic.szTopic) && lpTopic->nClass == m_Topic.nClass)
	{
		EnterCriticalSection(&m_CriticalSection);
		
		ListForEachEntry(Receiver,lpReceiver,&m_ReceiverList,m_ReceiverItem)
		{
			if (lpReceiver->m_uPublisherIPAddress == lpTopic->uPublisherIPAddress && lpReceiver->m_uPublisherPort == lpTopic->uPublisherPort)
			{
				bFound = 1;
				break;
			}
		}
		if (!bFound)
		{
			m_Topic.nClass = lpTopic->nClass;
			lpTopic->uSubscriberIPAddress	= m_Topic.uSubscriberIPAddress;
			lpTopic->uSubscriberPort		= m_Topic.uSubscriberPort;
			lpReceiver = new Receiver(this,lpTopic);
			if (lpReceiver->m_lpSubscriberChannel)
			{
				ListAddTail(&lpReceiver->m_ReceiverItem,&m_ReceiverList);//����һ�������������ӵĽڵ㣩���뵽ͷ�ڵ��ǰ��
				s_lpEventSocket->Send((char *)"Connected",10);
			}
			else
			{
				delete lpReceiver;
			}
		}	
		LeaveCriticalSection(&m_CriticalSection);
	}
}

int NetDDSSubscriber::DataReader(void *lpMsg,int nSize,DWORD nTimeout,BOOL *bValidity,BOOL *bRefresh)
{
	int nRet = 0;
	fd_set readfd;
	int Status;
	Receiver *lpReceiver,*lpNextReciver;
	struct timeval timeout;
	char szConnect[32];
	int bRecvData;
	unsigned long nLen;
	if (bValidity)
	{
		*bValidity = FALSE;
	}
	if (bRefresh)
	{
		*bRefresh = FALSE;
	}

	bRecvData = 0;

	while (!bRecvData)
	{
		FD_ZERO(&readfd);

		EnterCriticalSection(&m_CriticalSection);

		FD_SET(s_lpEventSocket->m_nSocket,&readfd);

		ListForEachEntrySafe(Receiver,lpReceiver,lpNextReciver,&m_ReceiverList,m_ReceiverItem)
		{
			FD_SET(lpReceiver->m_lpSubscriberChannel->m_nSocket,&readfd);
		}

		LeaveCriticalSection(&m_CriticalSection);


		if (nTimeout == INFINITE)
		{
			Status = select(0,&readfd,NULL,NULL,NULL);
		}
		else
		{
			if (m_nClass == TOPIC_QUEUE)
			{
				timeout.tv_sec = nTimeout / 1000;
				timeout.tv_usec = (nTimeout % 1000) * 1000;
			}
			else
			{
				timeout.tv_sec = 0;
				timeout.tv_usec = 0;
			}
			Status = select(0,&readfd,NULL,NULL,&timeout);
		}

		if (Status)
		{
			EnterCriticalSection(&m_CriticalSection);

			ListForEachEntrySafe(Receiver,lpReceiver,lpNextReciver,&m_ReceiverList,m_ReceiverItem)
			{
				if (FD_ISSET(lpReceiver->m_lpSubscriberChannel->m_nSocket,&readfd))
				{
					bRecvData = 1;
					nRet = lpReceiver->m_lpSubscriberChannel->Recv((char *)lpMsg,nSize);
					if (nRet < 0)
					{
						delete lpReceiver;
						nRet = 0;
					}
					else
					{
						memcpy(m_lpMessage,lpMsg,nRet);
						m_bEmpty = FALSE;
						m_nSize  = nRet;

						if (bValidity)
						{
							*bValidity = TRUE;
						}
						if (bRefresh)
						{
							*bRefresh = TRUE;
						}
						
						ListDel(&lpReceiver->m_ReceiverItem);
						ListAddTail(&lpReceiver->m_ReceiverItem,&m_ReceiverList);
						break;
					}
				}
			}

			LeaveCriticalSection(&m_CriticalSection);

			if (FD_ISSET(s_lpEventSocket->m_nSocket,&readfd))
			{
				nLen = 0;
				EnterCriticalSection(&s_ThreadCriticalSection);

				ioctlsocket(s_lpEventSocket->m_nSocket,FIONREAD,&nLen);	//

				if (nLen > 0)
				{
					s_lpEventSocket->Recv(szConnect,32);
				}
				LeaveCriticalSection(&s_ThreadCriticalSection);
			}
		}
		else
		{
			break;
		}
	}

	if (!nRet && m_nClass == TOPIC_SAMPLE && !m_bEmpty)
	{
		memcpy(lpMsg,m_lpMessage,m_nSize);
		nRet = m_nSize;
		if (bValidity)
		{
			*bValidity = TRUE;
		}
	}

	return nRet;
}

