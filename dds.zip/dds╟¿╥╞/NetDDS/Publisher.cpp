#include "../include/netdds.h"
#include "../include/commmiddleware.h"
#include"../CommMiddleware/TcpServerComponent.h"
#include "../queue/queue/queue.h"
#include <stdio.h>

NetDDSPublisher::NetDDSPublisher(CommComponent *lpTopicChannel,char *lpszLocalIPAddress,char *lpszMulticastIP,char *lpszTopic,int nSize,int nClass)
{
	if (nClass == TOPIC_QUEUE)
	{
		m_lpPublisherChannel	= CommFactroy(TCP_SERVER_COMPONENT,lpszLocalIPAddress,0);
		m_lpPublisherChannel->SetConnectEvent();
	}
	else
	{
		m_lpPublisherChannel	= CommFactroy(UDP_SERVER_COMPONENT,lpszLocalIPAddress,0,lpszMulticastIP);
	}
	if (m_lpPublisherChannel)
	{
		m_lpTopicChannel				= lpTopicChannel;
		m_nClass						= nClass;

		strcpy(m_Topic.szTopic,lpszTopic);
		m_Topic.nDDS					= NET_DDS;
		m_Topic.nType					= PUBLISH_TOPIC;
		m_Topic.nClass					= nClass;
		m_Topic.nSize					= nSize;
		m_Topic.uSubscriberIPAddress	= 0;
		m_Topic.uSubscriberPort			= 0;
		m_lpTopicChannel->GetAddress((unsigned int *)0,0,0,&m_Topic.uPublisherTopicPort);

		m_lpPublisherChannel->GetAddress(&m_Topic.uPublisherIPAddress,&m_Topic.uPublisherPort);

		EMPTY_LIST_HEAD(&m_PublisherItem);

		m_lpTopicChannel->Send((char *)&m_Topic,sizeof(m_Topic));
	}
}

NetDDSPublisher::~NetDDSPublisher()
{
	ListDel(&m_PublisherItem);
	if (m_lpPublisherChannel)
	{
		CommDestroy(m_lpPublisherChannel);
		m_lpPublisherChannel = 0;
	}
}

void NetDDSPublisher::PublisheTopic(_Topic *lpTopic)
{
	if (!strcmp(lpTopic->szTopic,m_Topic.szTopic) && lpTopic->nClass == m_Topic.nClass)
	{
		lpTopic->nType					= PUBLISH_TOPIC;
		lpTopic->nDDS					= NET_DDS;
		lpTopic->nClass					= m_Topic.nClass;
		lpTopic->uPublisherIPAddress	= m_Topic.uPublisherIPAddress;
		lpTopic->uPublisherPort			= m_Topic.uPublisherPort;
		lpTopic->uPublisherTopicPort	= m_Topic.uPublisherTopicPort;

		m_lpTopicChannel->Send((char *)lpTopic,sizeof(_Topic));
	}
}

int NetDDSPublisher::DataWriter(void *lpMsg,int nSize,DWORD nTimeout,int bGateway)
{
	if (m_lpPublisherChannel)
	{
		return m_lpPublisherChannel->Send((char *)lpMsg,nSize);
	}
	return 0;
}
