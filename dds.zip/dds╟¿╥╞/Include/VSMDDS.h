#ifndef __VSM_DDS_H__
#define __VSM_DDS_H__

#include "../Include/ShareMemDDS.h"

class VSMDDS : public ShareMemDDS
{
	private:
		char *GetShareMem(int nSize);
		void ShareMemInit(int nSize=0);

		void SpinLock(void *lpSystemTable);
		void SpinUnlock(void *lpSystemTable);

		inline void SetWaitingEvent(int nTopicNo,int nTpye);

		static void CALLBACK Monitor(UINT uID,UINT uMsg,DWORD dwUser,DWORD dw1,DWORD dw2);

	public:
		__declspec(dllexport) VSMDDS();
		__declspec(dllexport) ~VSMDDS();

		void ReleasePublisher(Publisher *lpPublisher);
		void ReleaseSubscriber(Subscriber *lpSubscriber);
};

#endif	__VSM_DDS_H__
