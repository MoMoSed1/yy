#ifndef __MESSAGE_H__
#define __MESSAGE_H__

#define _TEST_DDS_		0

#define _TEST_QUEUE

#define SPONSOR_RESPOND

#if (_TEST_DDS_ == 0)
	#define _DDS_	NetDDS
#elif (_TEST_DDS_ == 1)
	#define _DDS_	NetRelayDDS
#elif (_TEST_DDS_ == 2)
	#define _DDS_	VSMDDS
#elif (_TEST_DDS_ == 3)
	#define _DDS_	SVMICDDS
#elif (_TEST_DDS_ == 4)
	#define _DDS_	VMICDDS
#endif

#define TEST_SPONSOR_RESPOND_NUM		1000000

typedef struct
{
	int nID;
	char Msg[1024];
} _DATA_1;

typedef struct
{
	char szKey[32];
} _DATA_2;

#endif	/*__MESSAGE_H__*/
