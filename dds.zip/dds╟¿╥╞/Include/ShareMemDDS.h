#ifndef __SHARE_MEM_DDS_H__
#define __SHARE_MEM_DDS_H__

#include "../Include/DDS.h"

#define DISPLAY_TIME						1

#define MAX_TOPIC_NUM				(1024 * 32)

typedef struct _TopicEvent
{
	int					nTopicNo;
	char				szTopic[MAX_TOPIC_LEN + 1];
	int					nUpdateCount;
	HANDLE				hTopicPublish;
	HANDLE				hTopicSubscribe;
	HANDLE				hWrite;
	HANDLE				hRead;
	int					nFlag;
	CRITICAL_SECTION	PublishCriticalSection;
	CRITICAL_SECTION	SubscribeCriticalSection;
} _TopicEvent;

typedef struct _QueueHead
{
	short			nMessageSize;
	short			nMaxMessageNum;
	short			nHead;
	short			nTail;
} _QueueHead;

typedef struct
{
	char			Flag[MAX_SUBSCRIBER_PER_TOPIC];
	int				nSize;
	char			Body[1];
} _Message;

typedef struct _PublisherInfo
{
	HANDLE			hPublisher;
	_QueueHead		QueueHead;
	int				nMaxMessageNum;
	int				nSubscriberNo;
} _PublisherInfo;

class ShareMemDDS;

class ShareMemDDSPublisher : public Publisher
{
	private:
		HANDLE				m_lpPublisher;

		ShareMemDDS *		m_lpShareMemDDS;
		_TopicEvent *		m_lpTopicEvent;

		int					m_nSubscriberNum;

		_QueueHead			m_QueueHead;
		_Message **			m_MessageQueue;
		
		_Message *			m_lpMessage;
		
		BOOL				m_bRun;

	private:
		ShareMemDDSPublisher(ShareMemDDS *lpShareMemDDS,char *lpszTopic,int nSize,int nClass,int nMaxMessageNum);
		~ShareMemDDSPublisher();

		void GetSubscribeNum();
		BOOL ReleaseMessage(HANDLE hPublisher,_Message *lpMessage,int nHead);
		static DWORD ProcessPublish(void *arg);

	public:
		int DataWriter(void *lpMsg,int nSize,DWORD nTimeout,int bGateway=0);

	friend class ShareMemDDS;
};

class ShareMemDDSSubscriber : public Subscriber
{
	private:
		HANDLE				m_lpSubscriber;

		ShareMemDDS *		m_lpShareMemDDS;
		_TopicEvent *		m_lpTopicEvent;

		int					m_nIndex;
		int					m_nPublisherNum;

		_PublisherInfo		m_PublisherInfo[MAX_PUBLISHER_PER_TOPIC];
		_Message **			m_MessageQueue[MAX_PUBLISHER_PER_TOPIC];

		_Message *			m_lpMessage;

		BOOL				m_bRun;

	private:
		ShareMemDDSSubscriber(ShareMemDDS *lpShareMemDDS,char *lpszTopic,int nSize,int nClass,BOOL bGateway,int nMaxMessageNum);
		~ShareMemDDSSubscriber();

		void SubscriberTopic();
		static DWORD ProcessSubscriber(void *arg);

	public:
		int DataReader(void *lpMsg,int nSize,DWORD nTimeout,BOOL *bValidity = 0,BOOL *bRefresh = 0);

	friend class ShareMemDDS;
};

class ShareMemDDS : public DDS
{
	private:
		int					m_TopicNum;
		_TopicEvent			m_TopicEvent[MAX_TOPIC_NUM];

	public:
		HANDLE				m_hLockManager;

	private:
		void *GetSystemMem(int nLen,BOOL bLock);
		void FreeSystemMem(void *lpBlock);

		void *GetTopic(char *lpszTopic,int nMessageSize,int nType);
		_TopicEvent *GetTopicEvent(char *lpszTopic);

		DWORD WaitTime(HANDLE hEvent,unsigned long nTime);

		static BOOL WINAPI ConsoleHandler(DWORD CEvent);

	protected:
		void DDSInit();

		virtual void ShareMemInit(int nSize = 0) = 0;

		virtual void SpinLock(void *lpSystemTable) = 0;
		virtual void SpinUnlock(void *lpSystemTable) = 0;

		virtual inline void SetWaitingEvent(int nTopicNo,int nTpye) = 0;

		virtual inline void SendData(void *lpszDes,void *lpszSrc,int nLen);
		virtual inline void ReceiveData(void *lpszDes,void *lpszSrc,int nLen);

	public:
		virtual void StartMaster(){};
		void SpinLockEx(long *SystemSpinLockSection);
		void SpinUnlockEx(long *SystemSpinLockSection);
		void SetDDSEvent(int nTopicNo,int nType,BOOL bForceSet = 0);

		static DWORD LockManager(void *arg);
		static void CALLBACK CheckProcesses(UINT uID,UINT uMsg,DWORD dwUser,DWORD dw1,DWORD dw2);

	private:
		Publisher  *CreateGatewayPublisher(char *lpszTopic,int nSize,int nClass,int nMaxMessageNum);
		Subscriber *CreateGatewaySubscriber(char *lpszTopic,int nSize,int nClass,int nMaxMessageNum);


	public:
		ShareMemDDS();
		~ShareMemDDS();

		int IsValid();

		Publisher *CreateQueuingPublisher(char *lpszTopic,int nSize,int nMaxMessageNum = DEFAULT_MAX_MSG_NUM);
		Publisher *CreateSamplingPublisher(char *lpszTopic,int nSize,int nMaxMessageNum = DEFAULT_MAX_MSG_NUM);

		Subscriber *CreateQueuingSubscriber(char *lpszTopic,int nSize,int nMaxMessageNum = DEFAULT_MAX_MSG_NUM);
		Subscriber *CreateSamplingSubscriber(char *lpszTopic,int nSize,int nMaxMessageNum = DEFAULT_MAX_MSG_NUM);


#if (DISPLAY_TIME)
		void DisplayTime();
#endif

		friend class ShareMemDDSPublisher;
		friend class ShareMemDDSSubscriber;
};


#endif  __SHARE_MEM_DDS__

