#ifndef __SVMIC_DDS_H__
#define __SVMIC_DDS_H__

#include "../Include/ShareMemDDS.h"

class SVMICDDS : public ShareMemDDS
{
	private:
		void ShareMemInit(int nSize=0);

		void SpinLock(void *lpSystemTable);
		void SpinUnlock(void *lpSystemTable);
		inline void SetWaitingEvent(int nTopicNo,int nTpye);

		static void CALLBACK Monitor(UINT uID,UINT uMsg,DWORD dwUser,DWORD dw1,DWORD dw2);

	public:
		__declspec(dllexport) SVMICDDS();
		__declspec(dllexport) ~SVMICDDS();

		void ReleasePublisher(Publisher *lpPublisher);
		void ReleaseSubscriber(Subscriber *lpSubscriber);
};

#endif	__SVMIC_DDS_H__
