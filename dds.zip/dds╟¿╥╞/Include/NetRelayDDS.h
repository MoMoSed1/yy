#ifndef __NET_RELAY_DDS_H__
#define __NET_RELAY_DDS_H__

#include "dds.h"

class NetDDS;
class NetDDSSubscriber;
class CommComponent;

#define MAX_MESSAGE_LEN			(8*1024)
#define MAX_OUT_RELAY_NUM		20

class NetRelayDDSPublisher;
class NetRelayDDSSubscriber;

#ifndef LIST_HEAD_DEF

	#define LIST_HEAD_DEF
	typedef struct LIST_HEAD 
	{
#ifdef WIN32
		volatile struct LIST_HEAD *Next;
		volatile struct LIST_HEAD *Prev;
#else
		struct LIST_HEAD *Next;
		struct LIST_HEAD *Prev;
#endif
	} LIST_HEAD;

#endif /*LIST_HEAD_DEF*/

typedef struct
{
	LIST_HEAD	MessageItem;
	int			nSize;
	char		szMessage[1];
} _SubscriberMessage;

typedef struct
{
	unsigned int			uPublisherIPAddress;
	unsigned short			uPublisherPort;
	LIST_HEAD				ReceiverItem;
	LIST_HEAD				NetInRelayItem;
	NetRelayDDSSubscriber *	lpNetRelayDDSSubscriber;
} _Receiver;

typedef struct
{
	char					szTopic[MAX_TOPIC_LEN];
	unsigned int			uSubscriberIPAddress;
	unsigned short			uSubscriberPort;
	LIST_HEAD				SenderItem;
	LIST_HEAD				NetOutRelayItem;
	NetRelayDDSPublisher *	lpNetRelayDDSPublisher;
} _Sender;

class NetInRelay
{
	private:
		int	m_nClass;
		CommComponent *		m_lpSubscriberChannel;

		LIST_HEAD			m_NetInRelayItem;

		unsigned int		m_uPublisherIPAddress;
		unsigned short		m_uPublisherPort;

		char				m_szMessage[sizeof(_Topic) + MAX_MESSAGE_LEN];
		LIST_HEAD			m_ReceiverList;
		CRITICAL_SECTION	m_InRelaySection;

	public:
		NetInRelay(char *lpszServerIPAddress,unsigned short uServerPort,char *lpszLocalIPAddress,int nClass);
		~NetInRelay();

	private:
#ifdef WIN32
		static DWORD RecvTopicMessage(void *arg);
#else
		static void *RecvTopicMessage(void *arg);
#endif
		void Registe(_Receiver *lpReceiver);
		int Recv();

	friend class NetRelayDDS;
	friend class NetRelayDDSSubscriber;
};

class NetOutRelay
{
	private:
		CommComponent *		m_lpPublisherChannel;

		int					m_nClass;

		LIST_HEAD			m_SenderList;
		CRITICAL_SECTION	m_OutRelaySection;

		BOOL				m_bFirstWrite;
		unsigned long		m_dwCreateTime;

	public:
		NetOutRelay(char *lpszLocalIPAddress,unsigned long uMulticastIP,unsigned short uMulticastPort,int nClass);
		~NetOutRelay();

	private:
		void Registe(_Sender *lpSender);
		int Send(_Topic *lpTopic,char *lpszMessage,int nMsgLen);

	friend class NetRelayDDS;
	friend class NetRelayDDSPublisher;
};

class NetRelayDDSPublisher : public Publisher
{
	private:
		CommComponent *		m_lpTopicChannel;

		NetOutRelay *		m_lpNetOutRelay;

		_Topic				m_Topic;

		LIST_HEAD			m_PublisherItem;
		LIST_HEAD			m_SenderList;

		HANDLE				m_hConnectEvent;

		CRITICAL_SECTION	m_PublisherSection;

	private:
		NetRelayDDSPublisher(CommComponent *lpTopicChannel,NetOutRelay *lpNetOutRelay,char *lpszTopic,int nSize,int nClass);
		~NetRelayDDSPublisher();

		void CheckConnect();
		void PublisheTopic(_Topic *lpTopic);

	public:
		int DataWriter(void *lpMsg,int nSize,DWORD nTimeout,int bGateway=0);

		friend class NetRelayDDS;
};

class NetRelayDDSSubscriber : public Subscriber
{
	private:
		CommComponent *		m_lpTopicChannel;

		_Topic				m_Topic;
		int					m_bEmpty;
		int					m_nSize;
		void *				m_lpMessage;

		LIST_HEAD			m_SubscriberItem;

		LIST_HEAD			m_ReceiverList;
		LIST_HEAD			m_MessageList;

		HANDLE				m_hWaitEvent;

		CRITICAL_SECTION	m_SubscriberSection;

	private:
		NetRelayDDSSubscriber(CommComponent *lpTopicChannel,unsigned int uLocalIPAddress,unsigned short uLocalPort,char *lpszTopic,int nSize,int nClass);
		~NetRelayDDSSubscriber();

		void RecvMessage(_Topic *lpTopic,char *lpszMsg,int nSize);
		void ConnectPublisher(_Topic *lpTopic,LIST_HEAD	*lpInRelayList);

	public:
		int DataReader(void *lpMsg,int nSize,DWORD nTimeout,BOOL *bValidity = 0,BOOL *bRefresh = 0);

		friend class NetRelayDDS;
		friend class NetInRelay;
};

class NetRelayDDS : public DDS
{
	private:
		volatile int		m_bRunning;
		volatile int		m_bStoped;
		CommComponent *		m_lpTopicChannel;

		char				m_szLocalIPAddress[32];
		unsigned int		m_uMulticastIP;
		unsigned short		m_uMulticastPort;
		unsigned int		m_uLocalIPAddress;
		unsigned short		m_uLocalPort;

		LIST_HEAD			m_PublisherList;
		LIST_HEAD			m_SubscriberList;

		LIST_HEAD			m_NetQueuingInRelayList;
		LIST_HEAD			m_NetSamplingInRelayList;

		NetOutRelay	*		m_lpNetQueuingOutRelay[MAX_OUT_RELAY_NUM];
		int					m_nNetQueuingOutRelayNum;
		int					m_nMaxQueuingOutRelayNum;

		NetOutRelay	*		m_lpNetSamplingOutRelay[MAX_OUT_RELAY_NUM];
		int					m_nNetSamplingOutRelayNum;
		int					m_nMaxSamplingOutRelayNum;

		CRITICAL_SECTION	m_CriticalSection;

	private:
#ifdef WIN32
		static DWORD RecvTopic(void *arg);
#else
		static void *RecvTopic(void *arg);
#endif
		void ProcessTopic(_Topic *lpTopic);
		NetOutRelay *GetOutRelay(int nClass);

	public:
		DDS_EXPORT NetRelayDDS();
		DDS_EXPORT ~NetRelayDDS();

		int IsValid();
		Publisher *CreateQueuingPublisher(char *lpszTopic,int nSize,int nMaxMessageNum = DEFAULT_MAX_MSG_NUM);
		Publisher *CreateSamplingPublisher(char *lpszTopic,int nSize,int nMaxMessageNum = DEFAULT_MAX_MSG_NUM);

		Subscriber *CreateQueuingSubscriber(char *lpszTopic,int nSize,int nMaxMessageNum = DEFAULT_MAX_MSG_NUM);
		Subscriber *CreateSamplingSubscriber(char *lpszTopic,int nSize,int nMaxMessageNum = DEFAULT_MAX_MSG_NUM);

		void ReleasePublisher(Publisher *lpPublisher);
		void ReleaseSubscriber(Subscriber *lpSubscriber);
};

#endif  /*__NET_RELAY_DDS_H__*/
