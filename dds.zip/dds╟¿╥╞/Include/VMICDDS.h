#ifndef __VMIC_DDS_H__
#define __VMIC_DDS_H__

#include "../Include/ShareMemDDS.h"

class VMICDDS : public ShareMemDDS
{
	private:
		char *GetShareMem(long *nSize);
		void ShareMemInit(int nSize=0);

		void SpinLock(void *lpSystemTable);
		void SpinUnlock(void *lpSystemTable);

		inline void SetWaitingEvent(int nTopicNo,int nTpye);

		inline void SendData(void *lpszDes,void *lpszSrc,int nLen);
		inline void ReceiveData(void *lpszDes,void *lpszSrc,int nLen);

		void StartMaster();
		void SetMasterNode();
		void StartProcessEvent();

		static void CALLBACK Monitor(UINT uID,UINT uMsg,DWORD dwUser,DWORD dw1,DWORD dw2);

	public:
		__declspec(dllexport) VMICDDS();
		__declspec(dllexport) ~VMICDDS();


		void ReleasePublisher(Publisher *lpPublisher);
		void ReleaseSubscriber(Subscriber *lpSubscriber);
};

#endif	__VMIC_DDS_H__
